import os
from time import sleep

from pywinauto.findwindows import ElementNotFoundError
from selenium.common.exceptions import ElementNotInteractableException, \
    NoSuchElementException, NoSuchFrameException, TimeoutException, ElementNotVisibleException, \
    InvalidSelectorException, InvalidArgumentException
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from openpyxl import load_workbook
import openpyxl.utils.exceptions
from datetime import datetime
from pytz import timezone
from pywinauto.application import Application


class FireFox:
    driver = None
    homepage = "https://umusictest.service-now.com/nav_to.do?uri=%2Fwizard_view.do%3Fsysparm_wizardAction" \
               "%3Dsysverb_new%26sysparm_stack%3Dchange_request_list.do%26sysparm_parent" \
               "%3D8db4a378c611227401b96457a060e0f4%26sys_target%3Dchange_request"

    def __init__(self):
        profile = webdriver.FirefoxProfile()
        profile.set_preference('intl.accept_languages', 'en-US, en')
        driver_path = os.path.join(os.getcwd(), "geckodriver.exe")
        self.driver = webdriver.Firefox(executable_path=driver_path, firefox_profile=profile)

    def save_case_firefox(self, file, sender_name, message_path):
        try:
            work_book = load_workbook(filename=file, data_only=True)
            cr_template = work_book.get_sheet_by_name("CR Template")
            # Main request data
            request_change_type = cr_template['B6'].value
            request_submitted_by = cr_template['B10'].value
            request_assignment_group_name = cr_template['B14'].value
            request_configuration_item = cr_template['B16'].value
            request_category = cr_template['B18'].value
            request_change_priority = cr_template['B20'].value
            request_risk_level = cr_template['B22'].value
            request_change_impact = cr_template['B24'].value
            request_change_environment = cr_template['B28'].value
            request_change_summary = cr_template['B32'].value
            request_high_level_description = cr_template['B34'].value

            # Even though this provided in the high level description make sure to fill out rows 38-44
            request_scheduled_start_date = cr_template['B38'].value
            request_scheduled_start_time = cr_template['B39'].value
            request_scheduled_end_date = cr_template['B40'].value
            request_scheduled_end_time = cr_template['B41'].value
            request_duration = cr_template['B43'].value
            request_downtime = cr_template['B44'].value
            request_change_plan = cr_template['B46'].value
            request_back_out_plan = cr_template['B48'].value
            request_test_plan = cr_template['B50'].value

            request_tasks = []
            start_task_row_number = 54
            while True:
                if cr_template['B' + str(start_task_row_number)].value is None:
                    break
                current_dictionary = {
                    "description": cr_template['B' + str(start_task_row_number)].value,
                    "scheduled_start_date": cr_template['B' + str(start_task_row_number + 1)].value,
                    "scheduled_start_time": cr_template['B' + str(start_task_row_number + 2)].value,
                    "scheduled_end_date": cr_template['B' + str(start_task_row_number + 3)].value,
                    "scheduled_end_time": cr_template['B' + str(start_task_row_number + 4)].value,
                    "duration": cr_template['B' + str(start_task_row_number + 6)].value,
                    "downtime": cr_template['B' + str(start_task_row_number + 7)].value,
                    "assignment_group_name": cr_template['B' + str(start_task_row_number + 8)].value,
                }
                request_tasks.append(current_dictionary)
                start_task_row_number = start_task_row_number + 10

        except (
                openpyxl.utils.exceptions.CellCoordinatesException,
                openpyxl.utils.exceptions.IllegalCharacterError,
                openpyxl.utils.exceptions.InvalidFileException,
                openpyxl.utils.exceptions.NamedRangeException,
                openpyxl.utils.exceptions.ReadOnlyWorkbookException,
                openpyxl.utils.exceptions.SheetTitleException
        ):
            return "An error has occurred while reading the Excel spreadsheet received"

        try:
            # Go to homepage
            self.driver.get(self.homepage)
            # Wait for the iFrame where the list of requests types are located
            WebDriverWait(self.driver, 300).until(
                EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//*[@id="gsft_main"]'))
            )
            # Click on the appropriate link
            if "Emergency" in request_change_type:
                WebDriverWait(self.driver, 300).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//a[contains(text(), 'Emergency:')]")
                    )
                )
                self.driver.find_element_by_xpath("//a[contains(text(), 'Emergency:')]").click()
            elif "Minor" in request_change_type:
                WebDriverWait(self.driver, 300).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//a[contains(text(), 'Minor:')]")
                    )
                )
                self.driver.find_element_by_xpath("//a[contains(text(), 'Minor:')]").click()
            elif "Significant" in request_change_type:
                WebDriverWait(self.driver, 300).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//a[contains(text(), 'Significant:')]")
                    )
                )
                self.driver.find_element_by_xpath("//a[contains(text(), 'Significant:')]").click()
            elif "Standard" in request_change_type:
                WebDriverWait(self.driver, 300).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//a[contains(text(), 'Standard:')]")
                    )
                )
                self.driver.find_element_by_xpath("//a[contains(text(), 'Standard:')]").click()
            elif "Application Enhancement" in request_change_type:
                WebDriverWait(self.driver, 300).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//a[contains(text(), 'Application Enhancement:')]")
                    )
                )
                self.driver.find_element_by_xpath("//a[contains(text(), 'Application Enhancement:')]").click()
            elif "Application Maintenance" in request_change_type:
                WebDriverWait(self.driver, 300).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//a[contains(text(), 'Application Maintenance:')]")
                    )
                )
                self.driver.find_element_by_xpath("//a[contains(text(), 'Application Maintenance:')]").click()

            # Wait for the case number to be clickable
            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="sys_readonly.change_request.number"]')
                )
            )

            self.driver.find_element_by_xpath('//*[@id="header_add_attachment"]').click()
            # Wait for the file input to be clickable
            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="loadFileXml"]')
                )
            )
            self.driver.find_element_by_xpath('//*[@id="loadFileXml"]').click()
            try:
                app = Application().connect(title_re=".*File*", class_name='#32770')
            except ElementNotFoundError:
                app = Application().connect(title_re=".*archivos*", class_name='#32770')
            window = app.Dialog
            window.set_focus()
            window.Edit.set_text(message_path)
            window[u'&Open'].click_input()
            sleep(10)
            self.driver.find_element_by_xpath('//*[@id="attachment_closemodal"]').click()

            # Wait for the Requested by to be clickable
            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="sys_display.change_request.requested_by"]')
                )
            )
            # Requested by
            element = self.driver.find_element_by_xpath('//*[@id="sys_display.change_request.requested_by"]')
            element.clear()
            sleep(1)
            element.send_keys(request_submitted_by)

            # Assignment group
            self.driver.find_element_by_xpath('//*[@id="sys_display.change_request.assignment_group"]').send_keys(
                request_assignment_group_name)

            # Configuration Item
            self.driver.find_element_by_xpath('//*[@id="sys_display.change_request.cmdb_ci"]').send_keys(
                request_configuration_item.split('.')[0])

            # Category
            Select(self.driver.find_element_by_xpath('//*[@id="change_request.category"]')).select_by_visible_text(
                request_category)

            # Change Priority
            if "1. Critical" in request_change_priority:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.priority"]')).select_by_visible_text(
                    "1 - Critical")
            elif "2. High" in request_change_priority:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.priority"]')).select_by_visible_text(
                    "2 - High")
            elif "3. Moderate" in request_change_priority:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.priority"]')).select_by_visible_text(
                    "3 - Moderate")
            elif "4. Low" in request_change_priority:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.priority"]')).select_by_visible_text(
                    "4 - Low")
            elif "5. Planning" in request_change_priority:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.priority"]')).select_by_visible_text(
                    "5 - Planning")

            # Risk Level
            Select(self.driver.find_element_by_xpath('//*[@id="change_request.risk"]')).select_by_visible_text(
                request_risk_level)

            # Change Impact
            if "Extensive" in request_change_impact:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.impact"]')).select_by_visible_text(
                    "1 - Extensive")
            elif "Significant" in request_change_impact:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.impact"]')).select_by_visible_text(
                    "2 - Significant")
            elif "Moderate" in request_change_impact:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.impact"]')).select_by_visible_text(
                    "3 - Moderate")
            elif "Minor" in request_change_impact:
                Select(self.driver.find_element_by_xpath('//*[@id="change_request.impact"]')).select_by_visible_text(
                    "4 - Minor")

            # Change Environment
            if "Production" in request_change_environment:
                Select(self.driver.find_element_by_xpath(
                    '//*[@id="change_request.u_change_environment"]')).select_by_visible_text("PROD")
            elif "Development" in request_change_environment:
                Select(self.driver.find_element_by_xpath(
                    '//*[@id="change_request.u_change_environment"]')).select_by_visible_text("DEV")
            elif "Test" in request_change_environment:
                Select(self.driver.find_element_by_xpath(
                    '//*[@id="change_request.u_change_environment"]')).select_by_visible_text("TEST")

            # Summary
            self.driver.find_element_by_xpath('//*[@id="change_request.short_description"]').send_keys(
                request_change_summary)
            # description
            self.driver.find_element_by_xpath('//*[@id="change_request.description"]').send_keys(
                request_high_level_description)

            # Start Date and Time
            start_date_object = datetime.strptime(request_scheduled_start_date, '%m/%d/%Y').astimezone(
                timezone('US/Pacific')).date()
            start_dt = datetime.combine(start_date_object, request_scheduled_start_time)
            self.driver.find_element_by_xpath('//*[@id="change_request.start_date"]').send_keys(
                start_dt.strftime("%Y-%m-%d %H:%M:%S"))

            # End Date and Time
            end_date_object = datetime.strptime(request_scheduled_end_date, '%m/%d/%Y').astimezone(
                timezone('US/Pacific')).date()
            end_dt = datetime.combine(end_date_object, request_scheduled_end_time)
            self.driver.find_element_by_xpath('//*[@id="change_request.end_date"]').send_keys(
                end_dt.strftime("%Y-%m-%d %H:%M:%S"))

            # Duration
            self.driver.find_element_by_xpath('//*[@id="change_request.u_change_duration"]').send_keys(request_duration)

            # Downtime
            self.driver.find_element_by_xpath('//*[@id="change_request.u_downtime"]').send_keys(request_downtime)

            # Change Plan
            self.driver.find_element_by_xpath('//*[@id="change_request.change_plan"]').send_keys(request_change_plan)

            # Back Out Plan
            self.driver.find_element_by_xpath('//*[@id="change_request.backout_plan"]').send_keys(request_back_out_plan)

            # Test Plan
            self.driver.find_element_by_xpath('//*[@id="change_request.test_plan"]').send_keys(request_test_plan)

            # Communication Required
            Select(
                self.driver.find_element_by_xpath('//*[@id="change_request.u_comms_required"]')).select_by_visible_text(
                "No")

            # Click save
            self.driver.find_element_by_xpath('//*[@id="sysverb_update_and_stay_bottom"]').click()

            task_numbers = ""
            for request_task in request_tasks:
                # Wait for the 'Create Change Task' button
                WebDriverWait(self.driver, 300).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//button[contains(text(),'Create Change Task')]")
                    )
                )

                # Click the 'Create Change Task' button
                self.driver.find_element_by_xpath("//button[contains(text(),'Create Change Task')]").click()

                # task description
                change_task_description_element = self.driver.find_element_by_xpath(
                    '//*[@id="change_task.description"]')
                current_description = change_task_description_element.get_attribute('value')
                change_task_description_element.clear()
                change_task_description_element.send_keys(request_task["description"] + "\n\n" + current_description)

                # task assignment_group
                change_task_assignment_group_element = self.driver.find_element_by_xpath(
                    '//*[@id="sys_display.change_task.assignment_group"]')
                change_task_assignment_group_element.clear()
                sleep(1)
                change_task_assignment_group_element.send_keys(request_task["assignment_group_name"])

                # task scheduled start date and time
                task_start_date_object = datetime.strptime(request_task["scheduled_start_date"], '%m/%d/%Y').astimezone(
                    timezone('US/Pacific')).date()
                task_start_dt = datetime.combine(task_start_date_object, request_task["scheduled_start_time"])
                change_task_u_planned_start_date_element = self.driver.find_element_by_xpath(
                    '//*[@id="change_task.u_planned_start_date"]')
                change_task_u_planned_start_date_element.clear()
                sleep(1)
                change_task_u_planned_start_date_element.send_keys(task_start_dt.strftime("%Y-%m-%d %H:%M:%S"))

                # task scheduled end date and time
                task_end_date_object = datetime.strptime(request_task["scheduled_end_date"], '%m/%d/%Y').astimezone(
                    timezone('US/Pacific')).date()
                task_end_dt = datetime.combine(task_end_date_object, request_task["scheduled_end_time"])
                change_task_u_planned_end_date_element = self.driver.find_element_by_xpath(
                    '//*[@id="change_task.u_planned_end_date"]')
                change_task_u_planned_end_date_element.clear()
                sleep(1)
                change_task_u_planned_end_date_element.send_keys(task_end_dt.strftime("%Y-%m-%d %H:%M:%S"))

                # Get the task number
                task_number = self.driver.find_element_by_xpath(
                    '//*[@id="sys_readonly.change_task.number"]').get_attribute('value')
                # Add the task number to the task_numbers variable
                task_numbers = task_numbers + " - " + task_number + "\n"

                WebDriverWait(self.driver, 300).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//button[contains(text(),'Update')]")
                    )
                )
                self.driver.find_element_by_xpath("//button[contains(text(),'Update')]").click()

            ticket_number = self.driver.find_element_by_xpath(
                '//*[@id="sys_readonly.change_request.number"]').get_attribute('value')

            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="sysverb_update"]')
                )
            )
            self.driver.find_element_by_xpath('//*[@id="sysverb_update"]').click()

            message = """\
Greetings {}

We have created ticket {}
Tasks:
{}
Also we have assigned them to the corresponding team as requested.

Did you know?
You can now get IT help through chat and open / check the status of your own tickets at https://umusic.service-now.com/ess.

Regards, 
Global Service Desk | Universal Music Group
North America: +1 281 378 2974 | United Kingdom (UK): +44 207 660 6000 | Email: global.servicedesk@umusic.com\
"""

            return message.format(sender_name, ticket_number, task_numbers)

        except (
                ElementNotInteractableException,
                NoSuchElementException,
                NoSuchFrameException,
                TimeoutException,
                ElementNotVisibleException,
                InvalidSelectorException
        ):
            return "An error has occurred while saving the Service Now case."

    def login(self, username, password):
        try:
            self.driver.get(self.homepage)

            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="i0116"]')
                )
            )
            self.driver.find_element_by_xpath('//*[@id="i0116"]').send_keys(username)

            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="idSIButton9"]')
                )
            )
            self.driver.find_element_by_xpath('//*[@id="idSIButton9"]').click()

            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="passwordInput"]')
                )
            )
            self.driver.find_element_by_xpath('//*[@id="passwordInput"]').send_keys(password)

            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="submitButton"]')
                )
            )
            self.driver.find_element_by_xpath('//*[@id="submitButton"]').click()

            WebDriverWait(self.driver, 300).until(
                EC.frame_to_be_available_and_switch_to_it(
                    (By.XPATH, '//*[@id="duo_iframe"]')
                )
            )

            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, "//button[contains(text(),'Send Me a Push')]")
                )
            )
            self.driver.find_element_by_xpath("//button[contains(text(),'Send Me a Push')]").click()

            self.driver.switch_to.default_content()
            WebDriverWait(self.driver, 300).until(
                EC.presence_of_element_located(
                    (By.XPATH, '//*[@id="idSIButton9"]')
                )
            )

            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="KmsiCheckboxField"]')
                )
            )
            self.driver.find_element_by_xpath('//*[@id="KmsiCheckboxField"]').click()

            WebDriverWait(self.driver, 300).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '//*[@id="idSIButton9"]')
                )
            )
            self.driver.find_element_by_xpath('//*[@id="idSIButton9"]').click()

            WebDriverWait(self.driver, 300).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="gsft_main"]'))
            )
            return True
        except (
                ElementNotInteractableException,
                NoSuchElementException,
                NoSuchFrameException,
                TimeoutException,
                ElementNotVisibleException,
                InvalidSelectorException,
                InvalidArgumentException
        ):
            return False

    def quit(self):
        self.driver.quit()

    def close(self):
        self.driver.close()

    def refresh(self):
        self.driver.refresh()
