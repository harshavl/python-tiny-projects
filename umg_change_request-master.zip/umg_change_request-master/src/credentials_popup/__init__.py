from tkinter import messagebox, Tk, Frame, Label, Entry, TOP, X, LEFT, RIGHT, YES, Button
from re import match
import ctypes
from time import sleep
from os import startfile
import pythoncom
import win32com.client
from src.outlook_handler import OutlookHandler
from src.firefox_handler import FireFox
import sys
import psutil


def validate_email(email):
    if match(r'^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$', email) is not None:
        return True
    else:
        return False


# Function to check if outlook is open
def check_outlook_open():
    try:
        # If outlook open then return True
        if 'OUTLOOK.EXE' in (p.name() for p in psutil.process_iter()):
            return True
        else:
            return False
    except (psutil.ZombieProcess, psutil.AccessDenied, psutil.NoSuchProcess, ProcessLookupError):
        return False


class CredentialsPopup:
    popup_title = "UMG Change Request"

    def exit_script(self):
        self.root.destroy()
        sys.exit(0)
        # self.root.withdraw()

    def start_script(self):
        if self.username_entry.get() == "" or self.pass_entry.get() == "" or not validate_email(self.username_entry.get()):
            messagebox.showerror(self.popup_title, "Please provide valid credentials")
        else:
            self.root.withdraw()
            browser = FireFox()
            if not browser.login(self.username_entry.get(), self.pass_entry.get()):
                result = ctypes.windll.user32.MessageBoxW(
                    0,
                    "An error has occurred while login in to Service Now\n\nPlease manually sign in using Firefox and then "
                    "click OK.\n\nTo stop the script please click Cancel.",
                    self.popup_title, 17
                )
                if result == 2:  # User clicked cancel
                    browser.quit()
                    self.root.destroy()
                    sys.exit(0)
            # Loop
            OutlookHandler.browser = browser
            while True:
                # If outlook opened then it will start the DispatchWithEvents
                if not check_outlook_open():
                    # Stop pythoncom and set outlook variable to None to release memory
                    ctypes.windll.user32.PostQuitMessage(0)
                    startfile("outlook")
                    sleep(60)
                # To not check all the time (should increase 10 depending on your needs)
                win32com.client.DispatchWithEvents("Outlook.Application", OutlookHandler)
                pythoncom.PumpWaitingMessages()
                sleep(10)

    def __init__(self):
        # Main Window
        self.root = Tk()
        self.root.title(self.popup_title)

        # Username row
        username_row = Frame(self.root)
        self.username_label = Label(username_row, width=10, text="Username", anchor='w')
        self.username_entry = Entry(username_row, width=30, )
        username_row.pack(side=TOP, fill=X, padx=5, pady=5)
        self.username_label.pack(side=LEFT)
        self.username_entry.pack(side=RIGHT, expand=YES, fill=X)

        # Password row
        pass_row = Frame(self.root)
        self.pass_label = Label(pass_row, width=10, text="Password", anchor='w')
        self.pass_entry = Entry(pass_row, show="*", width=30, )
        pass_row.pack(side=TOP, fill=X, padx=5, pady=5)
        self.pass_label.pack(side=LEFT)
        self.pass_entry.pack(side=RIGHT, expand=YES, fill=X)
        # self.pass_entry.bind('<Return>', self.start_script)

        # Buttons
        b1 = Button(self.root, text='Start Script', command=self.start_script)
        b1.pack(side=RIGHT, padx=5, pady=5)
        b2 = Button(self.root, text='Quit', command=self.exit_script)
        b2.pack(side=RIGHT, padx=5, pady=5)

        self.root.protocol('WM_DELETE_WINDOW', self.exit_script)
        self.root.bind("<Escape>", lambda q: self.exit_script())
        self.root.bind("<Return>", lambda q: self.start_script())

        self.root.mainloop()
