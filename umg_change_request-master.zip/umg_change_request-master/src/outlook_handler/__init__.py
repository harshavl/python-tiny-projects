import asyncio
import os
import ctypes


class OutlookHandler(object):
    browser = None
    folder = "UMG Processed Emails"

    async def save_snow_case(self, attachment, reply, sender_name, message_path):
        print("    -> Creating SNow Case.")
        reply.Body = self.browser.save_case_firefox(attachment, sender_name, message_path)
        reply.Send()
        print("    -> Sending reply with SNow Case.")
        os.remove(attachment)
        os.remove(message_path)
        print("    -> Deleting attachment from disk.")

    def process_email(self, message, folder):
        if "UMG CHANGE REQUEST" in message.Subject:
            # Log email entry
            print("Processing emails from : " + message.SenderName)
            # iterate thought the email's attachments
            if message.Attachments.Count > 1:
                print("  -> Found " + str(message.Attachments.Count) + " attachments")
                for attachment in message.Attachments:
                    if "xlsx" in attachment.FileName:
                        print("    -> Processing attachment " + attachment.FileName + ".")
                        attachment_name = os.path.join(os.getcwd(), str(attachment.FileName))
                        attachment.SaveAsFile(attachment_name)
                        print("    -> Saving attachment to " + attachment_name + ".")
                        message_path = os.path.join(os.getcwd(), "UMG Change Request.msg")
                        print("    -> Saving message to " + message_path + ".")
                        message.SaveAs(message_path)
                        reply = message.Reply()
                        print("    -> Creating reply.")
                        asyncio.run(self.save_snow_case(attachment_name, reply, message.SenderName, message_path))
            else:
                reply = message.Reply()
                reply_message = f"Hi {message.SenderName}. \n" \
                                f"\n" \
                                f"Thank you for submitting a Change Request but it seems that you forgot to attach the " \
                                f"details of the request. Please reply back with the Request Details using the " \
                                f"standard template. \n" \
                                f"\n" \
                                f"Thank you!."
                reply.Body = reply_message
                reply.Send()
            message.UnRead = False
            message.Move(folder)
        else:
            # Log email entry
            print("Email from " + message.SenderName + " not processed")

    def __init__(self):
        print("Processing existing emails..")
        # First action to do when using the class in the DispatchWithEvents
        inbox = self.Application.GetNamespace("MAPI").GetDefaultFolder(6)
        # Check for unread emails when starting the event
        for message in inbox.Items:
            self.process_email(message, inbox.Folders[self.folder])
        print("Done processing emails..")

    def OnQuit(self):
        # To stop PumpMessages() when Outlook Quit
        # Note: Not sure it works when disconnecting!!
        ctypes.windll.user32.PostQuitMessage(0)

    def OnNewMailEx(self, receivedItemsIDs):
        # RecrivedItemIDs is a collection of mail IDs separated by a ",".
        # You know, sometimes more than 1 mail is received at the same moment.
        for ID in receivedItemsIDs.split(","):
            mail = self.Session.GetItemFromID(ID)
            folder = self.Application.GetNamespace("MAPI").GetDefaultFolder(6).Folders[self.folder]
            self.process_email(mail, folder)
