from src.credentials_popup import CredentialsPopup


if __name__ == "__main__":
    popup_title = "UMG Change Request"
    app = CredentialsPopup()
