# RPA - UMG Change Request
This RPA solution will scan Outlook every 10 seconds looking for emails with the subject "UMG CHANGE REQUEST" and an Excel attachment.
If the search criteria is met, the message will be saved and attached to a Service Now case with the information provided in the Excel attachment.
Once the Service Now case is saved, the bot will reply with the Case Number and all Tasks numbers.

## Prerequisites

- Are admin rights required?
  - No
- Is required to restart the PC?
  - No
- Corporate connectivity required?
  - No

## Output

The script logs its actions to the console but will not save anything.

## Requirements

### Production
Please understand that the following requirements are necessary so the bot can run properly
- Mozilla Firefox must be installed on the computer to save Service Now cases
- A valid Outlook profile set up
- A folder inside of the Inbox named UMG Processed Emails.

### Development
The script was develop using Python so it requires
- Python 3.7.4
- Virtualenv

#### How to modify it
- Create a virtual environment
- Change directory to the newly created environment
- Clone the repo
- Change directory to the src folder
- Activate virtual environment
- Run pip install -r requirements.txt

## Features

- Prompt for credentials to automatically login to Service Now reducing the human intervention to just accepting the Duo Push
- In case that the credentials are invalid and the bot can’t login, a pop-up message will be displayed so the agent can manually login and then click OK(DO NOT click OK before completing the login process)
- Scans Outlook’s Mailbox for incoming messages with the Subject UMG Change Request and an attachment (Excel File)
  - Reads the Attachment and save its contents to Service Now
  - Attaches the original message to Service Now case
- Reply to the sender with the Service Now case and all its related tasks (Example reply attached to this email)
  - Reply will be sent using Outlook


## Deployment

Since this RPA Solution was an special request, the deployment will be managed by the account

Please use the files located on the **dist folder**

## Platform

Windows.

## Framework

- Python compiled to exe.

## Version

1.1

## Author

[Erick Castrillo](mailto:erick.castrillo@dxc.com)
